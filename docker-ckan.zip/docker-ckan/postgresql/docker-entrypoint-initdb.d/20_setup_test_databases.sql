CREATE DATABASE ckan_test OWNER ckan ENCODING 'utf-8';
CREATE DATABASE datastore_test OWNER ckan ENCODING 'utf-8';
