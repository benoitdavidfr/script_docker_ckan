import ckanext.harvest.logic.auth.update as _update

harvest_source_patch = _update.harvest_source_update
