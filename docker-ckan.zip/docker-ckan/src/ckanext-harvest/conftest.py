# -*- coding: utf-8 -*-

pytest_plugins = [
    u'ckanext.harvest.tests.fixtures',
]
